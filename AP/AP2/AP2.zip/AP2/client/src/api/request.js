import axios from "axios";

export function getItens() {
	return axios({
		method: "GET",
		url: "https://jsonplaceholder.typicode.com/todos",
	});
}

export function postItens(dados) {
	return axios({
		method: "POST",
		url: "https://jsonplaceholder.typicode.com/todos",
		data: { title: dados.titulo },
	});
}
