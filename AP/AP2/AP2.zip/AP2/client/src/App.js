import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { PaginaMostrar } from "./pages/PaginaMostrar";
import { PaginaCadastro } from "./pages/PaginaCadastro";

function App() {
	return (
		<div className="App">
			<BrowserRouter>
				<Routes>
					<Route path="/mostrar" element={<PaginaMostrar></PaginaMostrar>} />
					<Route path="/cadastro" element={<PaginaCadastro></PaginaCadastro>} />
				</Routes>
			</BrowserRouter>
		</div>
	);
}

export default App;
