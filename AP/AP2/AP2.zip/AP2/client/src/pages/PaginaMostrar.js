import { useEffect, useState } from "react";
import { getItens } from "../api/request";

export function PaginaMostrar() {
	const [itens, setItens] = useState([]);

	useEffect(() => {
		getItens()
			.then(res => {
				console.log(res);
				setItens(res.data);
			})
			.catch(e => console.log(e));
	}, []);

	const cards = [];
	for (const item of itens) {
		cards.push(<DetalheItem key={item.id} titulo={item.title}></DetalheItem>);
	}

	return <div className="PaginaMostrar">{cards}</div>;
}

export function DetalheItem(props) {
	return <div className="DetalheItem">{props.titulo}</div>;
}
