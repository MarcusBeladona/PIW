import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { postItens } from "../api/request";

export function PaginaCadastro() {
	const { register, handleSubmit } = useForm();
	const navigate = useNavigate();

	function adicionarItem(dados) {
		postItens(dados)
			.then(res => {
				console.log(res);
				alert("Item adicionado com sucesso!");
				navigate("/mostrar");
			})
			.catch(e => console.log(e));
	}

	return (
		<div className="PaginaCadastro">
			<form onSubmit={handleSubmit(adicionarItem)}>
				<input {...register("titulo")} type="text" placeholder="Titulo" />
				{/* <input {...register("texto")} type="text" placeholder="Texto" /> */}
				<button type="submit">Submeter</button>
			</form>
		</div>
	);
}
