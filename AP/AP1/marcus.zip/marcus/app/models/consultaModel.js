const mongoose = require("mongoose");

module.exports = (function () {
	var schema = mongoose.Schema({
		id: { type: mongoose.Schema.Types.ObjectId },

		usuarioId: {
			type: mongoose.Schema.Types.ObjectId,
			required: true,
		},
		medicoId: {
			type: mongoose.Schema.Types.ObjectId,
			required: true,
		},
	});
	return mongoose.model("Consulta", schema);
})();
