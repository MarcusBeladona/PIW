let c = 2;

function f(x){
    return 2*x;
}

module.exports.b = c;
module.exports.f = f;